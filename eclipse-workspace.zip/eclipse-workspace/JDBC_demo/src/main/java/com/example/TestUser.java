package com.example;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context =  new ClassPathXmlApplicationContext("applicationContext.xml"); 
		//Resource rs=new ClassPathResource("applicationContext.xml");
		//BeanFactory factory=new XmlBeanFactory(rs);
		
		UserDAO userdao=(UserDAO) context.getBean("userDAO");
		int result=userdao.saveUser(new Users(101,"sample1@gmail.com","falsfj"));
		System.out.println(result);
		int result1=userdao.saveUser(new Users(102,"sample2@gmail.com","fal12"));
		System.out.println(result1);
		int result2=userdao.saveUser(new Users(103,"sample3@gmail.com","fals23"));
		System.out.println(result2);
		int result3=userdao.updateUser(new Users(101,"update@gmail.com","admin123"));
		System.out.println(result3);
		int result4=userdao.deleteUser(new Users(103,"sample3@gmail.com","fals23"));
		System.out.println(result4);
	}

}

