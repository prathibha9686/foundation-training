package javaconditions;

public class Test2 {
public static void main(String[] args) {
	int percentage = 90;

	if (percentage >= 85 && percentage <100) {
		System.out.println("fcd");
	}
	else if(percentage >= 60 && percentage <85) {
		System.out.println("first class");
}
else if(percentage >=35 && percentage <60){
	System.out.println("pass class");
	
}else if(percentage >=0 && percentage <35) {
	System.out.println("fail");
}else
{ System.out.println("enter percentage between 0 and 100");
		
		
		
	}
}

}
