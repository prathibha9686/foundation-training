package javacollections;
import java.util.ArrayList;
public class Test1 {
public static void main(String[] args) {
	ArrayList<String> a1= new ArrayList<String>();
	a1.add("Jimmy");
	a1.add("john");
	
System.out.println(a1.get(1));}
}
