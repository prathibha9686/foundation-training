package javacollections;
import java.util.Vector;
import java.util.Iterator;
public class Test7 {
public static void main(String[] args) {
	Vector<Integer> a1= new Vector<Integer>();
	a1.add(10);
	a1.add(20);
	a1.add(30);
	a1.add(40);

	Iterator it = a1.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
		}
}}
