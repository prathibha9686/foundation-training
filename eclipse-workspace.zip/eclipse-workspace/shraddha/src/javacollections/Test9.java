package javacollections;
import java.util.PriorityQueue;
import java.util.Iterator;
public class Test9 {
public static void main(String[] args) {
	PriorityQueue<Integer> a1= new PriorityQueue<Integer>();
	a1.add(10);
	a1.add(20);
	a1.add(30);
	a1.add(40);
	Iterator it = a1.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
		}
	System.out.println("--------");
	a1.remove();
	a1.poll();
	Iterator it1 = a1.iterator();
	while(it1.hasNext()) {
		System.out.println(it1.next());
		}
}}
