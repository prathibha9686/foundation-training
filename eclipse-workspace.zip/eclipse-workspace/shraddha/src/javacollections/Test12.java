package javacollections;
import java.util.LinkedList;
import java.util.Deque;
public class Test12 {
	public static void main(String[] args) {
		Deque<String> deque=new LinkedList<String>();
		deque.add("Item2");
		deque.addFirst("Item1");
		deque.addLast("Item3");
		deque.push("Item4");
		System.out.println(deque);
		deque.pop();
		System.out.println("--------");
		System.out.println(deque);
		deque.pollLast();
		System.out.println("--------");
		System.out.println(deque);
		System.out.println("--------");
		deque.remove();
		System.out.println(deque);
		System.out.println("--------");
		deque.remove();
		System.out.println(deque);
	}
	
	

}
