package javacollections;
import java.util.ArrayDeque;
import java.util.Deque;

public class Test13 {
	public static void main(String[] args) {
		Deque <Integer>a1=new ArrayDeque<Integer>();
		a1.add(10);
		a1.add(30);
		a1.add(60);
		a1.add(40);
		System.out.println(a1);
		System.out.println("----------------");
		a1.clear();
		System.out.println(a1);
	}

}
