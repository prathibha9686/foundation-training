package javacollections;
import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;

public class Test15{
public static void main(String[] args) {
	Set<Integer> set=new HashSet<Integer>();
	set.add(10);
	set.add(20);
	set.add(10);
	set.add(40);
Iterator obj=set.iterator();
while(obj.hasNext()) {

	System.out.println(obj.next());

}
}}
