package javacollections;
import java.util.PriorityQueue;
import java.util.Iterator;
public class Test11 {
public static void main(String[] args) {
	PriorityQueue<Character> a1= new PriorityQueue<Character>();
	a1.add('z');
	a1.add('h');
	a1.add('a');
	a1.add('i');
	Iterator it = a1.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
		}
	System.out.println("--------");
	a1.remove();
	a1.poll();
	Iterator it1 = a1.iterator();
	while(it1.hasNext()) {
		System.out.println(it1.next());
		}
}}
