package javacollections;
import java.util.LinkedList;
import java.util.Iterator;
public class Test6 {
public static void main(String[] args) {
	LinkedList<String> a1= new LinkedList<String>();
	a1.add("shraddha");
	a1.add("nayana");
	a1.add("vardhan");
	a1.add("gunasri");

	Iterator it = a1.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
		}
}}
