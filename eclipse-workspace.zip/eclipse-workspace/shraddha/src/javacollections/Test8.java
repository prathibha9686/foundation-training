package javacollections;
import java.util.Stack;
import java.util.Iterator;
public class Test8{
public static void main(String[] args) {
	Stack<Integer> a1= new Stack<Integer>();
	a1.add(10);
	a1.add(20);
	a1.add(30);
	a1.add(40);

	Iterator it = a1.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
		}
	System.out.println("---------");
    a1.remove(1);
	a1.pop();
	Iterator it1 = a1.iterator();
	while(it1.hasNext()) {
		System.out.println(it1.next());
		}
	
}}
