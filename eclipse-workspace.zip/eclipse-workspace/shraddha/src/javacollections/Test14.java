package javacollections;
import java.util.HashSet;
import java.util.Set;

public class Test14 {
public static void main(String[] args) {
	Set<String> set=new HashSet<String>();
	set.add("john");
	set.add("jack");
	set.add("joe");
	set.add("john");
	System.out.println(set);
}
}
