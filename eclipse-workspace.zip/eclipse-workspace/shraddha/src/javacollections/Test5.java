package javacollections;
import java.util.LinkedList;
import java.util.Iterator;
public class Test5 {
public static void main(String[] args) {
	LinkedList<Integer> a1= new LinkedList<Integer>();
	a1.add(10);
	a1.add(20);
	a1.add(30);
	a1.add(40);

	Iterator it = a1.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
		}
}}
