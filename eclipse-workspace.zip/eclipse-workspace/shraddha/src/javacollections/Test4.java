package javacollections;
import java.util.ArrayList;
import java.util.Iterator;
public class Test4 {
public static void main(String[] args) {
	ArrayList<String> a1= new ArrayList<String>();
	a1.add("null");
	a1.add("nayana");
	a1.add("vardhan");
	a1.add("gunasri");

	Iterator it = a1.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
		}
}}
