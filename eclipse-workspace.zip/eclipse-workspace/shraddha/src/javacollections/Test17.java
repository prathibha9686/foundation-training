package javacollections;
import java.util.HashMap;
public class Test17 {
public static void main(String[] args) {
	HashMap<Integer,String> map=new HashMap<Integer,String>();
	map.put(1, "shraddha");
	map.put(2, "nayana");
	map.put(3, "vardhan");
	map.put(4, "gunasri");
	 System.out.println(map);
	
}
}
