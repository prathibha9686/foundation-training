package javaexception;
class A1{
	int num;
	A1(int num){
		this.num=num;
	}
	void display() {
		System.out.println("number is :" +num);
	}}
class B1 extends A1{
	B1(int num){
		super(num);}
		void display() {
			System.out.println("number is : "+num+" from class B1");
			}}
public class Test8 {
	public static void main(String[] args) {
		B1 b1=new B1(20);
		A1 a1= new A1(30);
 
		try {
		A1 obj3=new A1(40);
		B1 ob= (B1)obj3;
	}catch (Exception e) {
		System.out.println(e);
	}finally {
		System.out.println("executes always");
	}
	}}


