package javaexception;
public class Test10 {
static boolean checkAge( int age)
{ if(age<18)
{ throw new ArithmeticException("not eligible for voting");
}else {
	return true;
}	
}
public static void main(String[] args) {
	int age1=20;
	int age2=3;
 try {
	 if(checkAge(age2)){
		 System.out.println("eligible for voting");
	 }
 }catch (Exception e) {
	 System.out.println( e.getMessage());
		 }
	 }
}


