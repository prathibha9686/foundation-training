package javaexception;

public class Finallyy {
	public static void main(String[] args) {
		
	try {
		int a = 5;
	}
	catch(Exception e) {
		System.out.println(e);
	}finally {
		System.out.println("this is finally");
	}
	}

}
