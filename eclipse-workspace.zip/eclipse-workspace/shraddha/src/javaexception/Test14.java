package javaexception;

public class Test14 {
	public static void main(String[] args) {
		
	
	int i=1;
	try {
	if(i<10)
		throw new ArithmeticException();
}catch(ArithmeticException e) {
	System.out.println(e);
}}}
