package javaexception;

public class Test3 {

public static void main(String[] args) {
	int num=20;


	try {
		System.out.println(num/0);
	} catch(NullPointerException e) {
	System.out.println("I am null");
	System.out.println(e);
	}
	catch (ArithmeticException e) {
		System.out.println(num/(0+1));
	
}
}}
