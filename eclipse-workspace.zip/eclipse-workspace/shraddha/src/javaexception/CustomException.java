package javaexception;
import java.security.DomainCombiner;

class InvalidUserException extends Exception{

	public InvalidUserException(String msg) {
super(msg);
	}
}

public class CustomException {
static void validateuser(String username,String password) throws InvalidUserException{
	if(username.equals("abcd")&& password.equals("abcd123")) {
		System.out.println("user is valid");
	}else {
		throw new InvalidUserException("invalid user");
		
	}
	
	}public static void main(String[] args) {
		try {
			validateuser("abcd","abcd1234");
		} catch (InvalidUserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
