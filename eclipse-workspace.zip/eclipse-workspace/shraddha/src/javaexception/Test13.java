package javaexception;
import java.io.IOException;
 class A11{
	 void display() throws IOException{
	System.out.println("msg from display");	 
	 }
 }
public class Test13 {
public static void main(String[] args) throws IOException {
	A11 obj=new A11();
	obj.display();
}
}
