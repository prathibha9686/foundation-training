package javaexception;

public class Test6 {
	public static void main(String[] args) {
		int num=20;
		String name = null;
		int[] numbers= { 30,40,50,20,60};

		try {
			System.out.println(name.length());
			System.out.println(numbers[6]);
			System.out.println(num/0);}
			catch(NullPointerException e) {
				System.out.println("I am null");
				System.out.println(e);
				}
				catch (ArithmeticException e) {
					System.out.println(num/(0+1));
				
			}catch (ArrayIndexOutOfBoundsException ex) {
				System.out.println("exception occured by AIOBE block:" +ex);
			
		
	}catch (Exception ex) {
		System.out.println("exception occured "+ex);
	}}}
	
	

	


