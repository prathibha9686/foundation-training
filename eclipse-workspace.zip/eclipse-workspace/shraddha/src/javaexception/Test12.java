package javaexception;

public class Test12 {
public static void main(String[] args) {
	try {
		System.out.println("with in try");
	}catch (Exception e) {
		System.out.println(e);
	}
}
}
