package javaexception;

public class Test9 {
	static boolean checkNumber(int n) {
		if(n==0)
		{   throw new ArithmeticException("divide by zero error");
		}else {
			return true;
		}
		}
		public static void main(String[] args) {
		int num1=200;
		int num2=0;
		int result;
		
	
		System.out.println(1);
		
	
	try {
		result= num1/num2;
		
		if(checkNumber(num2)) {
				
			System.out.println("division result of two numbers:" +result);
			}
		}catch (Exception e) {
			System.out.println("from catch inside main:"+e.getMessage());
		}
		System.out.println(2);
	}
	}
	