package javaexception;

public class Test11 {
	static void task() throws NullPointerException{
		System.out.println("with in task");
		throw new NullPointerException("null" );
		}
	
	public static void main(String[] args) throws NullPointerException{
		
			
		try {
			task();
		}catch(NullPointerException e)
		{
		System.out.println(e);
	}	}}


