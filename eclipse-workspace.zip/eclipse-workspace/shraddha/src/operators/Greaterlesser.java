package operators;

public class Greaterlesser {
	public static void main(String[] args) {
		int num1=70;
		int num2=80;
		System.out.println(num1 > num2);
		System.out.println(num1 < num2);
	}

}
