package operators;

public class Postinc {
	public static void main(String[] args) {
		int num=6;
		num++;
		
		System.out.println(num);
	}

}
