package operators;

public class Ifelse {
public static void main(String[] args) {
	int age=18 ;
	if (age>=18) {
System.out.println("eligible");
	System.out.println("proceed to vote");
	} else
		System.out.println("not eligible");
}}
