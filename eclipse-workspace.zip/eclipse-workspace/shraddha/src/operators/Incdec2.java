package operators;

public class Incdec2 {
	public static void main(String[] args) {
		int num=10;
		num++;
		System.out.println(num);
		++num;
		System.out.println(num);
		num--;
		System.out.println(num);
		--num;
		System.out.println(num);
		
	}

}
