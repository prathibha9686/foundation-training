package operators;

public class Arithmaticop {
      public static void main(String[] args) {
    	  int num1=10;
    	  int num2=15;
    	  System.out.println(num1 + num2);
    	  System.out.println(num1 - num2);
    	  System.out.println(num1 * num2);
    	  System.out.println(num2 % num1);
		
	}
}
