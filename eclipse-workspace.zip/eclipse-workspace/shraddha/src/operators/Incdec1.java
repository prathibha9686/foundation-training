package operators;

public class Incdec1 {
	public static void main(String[] args) {
		int num=5;
		num++;
		num--;
		System.out.println(num);
	}

}
