package javapolymorphism;
class EmpName{
	String emp_name="John";
	void display() {
		System.out.println(emp_name +" ");
		
	}
}
class EmpId{
	int emp_id=102;
	void display() {
		System.out.println(emp_id + " ");
		
	}
}
public class functionoverriding3 {
	public static void main(String[] args) {
		
	
	EmpId obj=new EmpId();
	obj.display();
}



}
