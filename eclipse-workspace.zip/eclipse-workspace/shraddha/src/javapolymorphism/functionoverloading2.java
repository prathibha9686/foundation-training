package javapolymorphism;
class Calculation2{
	int addition(int x,int y) {
		return x+y;
	}
	double addition(double x,double y) {
		return x+y;
		}
	}

public class functionoverloading2 {
	public static void main(String[] args) {
		double result;
		int result1;
		Calculation2 obj=new Calculation2();
		result=obj.addition(4.6, 2.5);
		System.out.println(result);
		result1=obj.addition(5, 8);
		System.out.println(result1);
		
	}

}
