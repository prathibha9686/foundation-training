package javapolymorphism;
class W1{
	void display() {
		System.out.println("message from display W1");
	}
}
class W2 extends W1{
	void display() {
		System.out.println("message from display W2");
	}
}

public class functionoverriding {
	public static void main(String[] args) {
		W2 obj=new W2();
		obj.display();
	}
	

}
