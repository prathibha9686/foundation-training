package javapolymorphism;
class Vehicle{
	void display() {
		System.out.println("vehicle");
		
	}
}
class Bike{
	void display() {
		System.out.println("bike");
		
	}
}
public class functionoverriding2 {
	public static void main(String[] args) {
		
	
	Bike obj=new Bike();
	obj.display();
}
}
