package javaarrays;

public class Array3 {
	public static void main(String[] args) {
		int arr[]= {1,2,4,9,6};
		for (int i: arr)
		{
			System.out.println(i);
		}
	}

}
