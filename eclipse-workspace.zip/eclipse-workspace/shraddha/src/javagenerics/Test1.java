package javagenerics;
class A<T>{
	T i;
	A(T val){
		this.i=val;
	}
	
	}

public class Test1 {
public static void main(String[] args) {
	A <Integer> obj = new A<Integer>(20);
	System.out.println(obj.i);
	A <String> obj1 = new A<String>("Shraddha");
System.out.println(obj1.i);
A <Character> obj2 = new A<Character>('a');
System.out.println(obj2.i);
A <Double> obj3 = new A <Double> (10000.99);
System.out.println(obj3.i);
A <Boolean> obj4 = new A<Boolean>(true);
System.out.println(obj4.i);


}
}
