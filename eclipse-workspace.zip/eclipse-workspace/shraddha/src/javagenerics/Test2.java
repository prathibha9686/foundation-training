package javagenerics;
class A1<T,U>{
	T p1;
	U p2;
	A1(T p1, U p2){
		this.p1=p1;
		this.p2=p2;
	}void  display(){
		System.out.println(p1 + " " + p2);
	}
}
public class Test2 {
public static void main(String[] args) {
	A1<String,Integer> obj1= new A1<String,Integer>("john",6);
	obj1.display();
}
}

