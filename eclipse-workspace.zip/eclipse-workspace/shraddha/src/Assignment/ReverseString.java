package Assignment;

public class ReverseString {
	public static void main(String[] args) {
		String str="WELCOME";
		String revStr="";
		System.out.println(str);
		int strLength= str.length();
		for(int i=(strLength -1);i>=0;--i) {
	
			revStr=revStr + str.charAt(i);
		}
			System.out.println(" the reverse of the string "+str+ " is " +revStr);
			}
}