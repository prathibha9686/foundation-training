package Assignment;

public class Palindrome {
	public static void main(String[] args) {
		String str="madam";
		String revStr="";
		System.out.println(str);
	int strLength=str.length();
		for(int i=( strLength-1);i>=0;--i) {
			revStr=revStr + str.charAt(i);
			
			System.out.println(revStr);
			}
		if(str.equals(revStr)) {
			System.out.println(str + " is a Palindrome");
		}
		else {
			System.out.println(str + " is not a Palindrome");
		}
		
	}

}
