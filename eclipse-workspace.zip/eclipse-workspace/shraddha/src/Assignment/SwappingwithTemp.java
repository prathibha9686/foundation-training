package Assignment;

public class SwappingwithTemp {
	public static void main(String[] args) {
		
	
	int num1=2,num2=4,temp=0;
	System.out.println("before swapping num1="+num1+  " and num2=" + num2);
	temp=num1;
	num1=num2;
	num2=temp;
	System.out.println("after swapping num1="+num1+  " and num2=" + num2);

}}
