package Assignment;

import java.util.Scanner;

public class Factorial{
	public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.println("enter a number");
    int num=sc.nextInt();
if(num>=0)
{
	int fac=1;
	for(int i=num;i>=1;i--)
   fac=fac*i;
	System.out.println("factorial of "+num+" is "+fac);
}
else
	System.out.println("enter a valid number ");
	}}
