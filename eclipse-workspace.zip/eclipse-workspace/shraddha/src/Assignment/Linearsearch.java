package Assignment;

public class Linearsearch {
	public static void main(String[] args) {
int arr[]= {40, 50 ,60 , 70};

int key=60;


for(int i=0;i < arr.length;i++) {
	if(arr[i]==key) {
		
		System.out.println(key+" is found at index:" +i);
	}
	

	
	}	}}

