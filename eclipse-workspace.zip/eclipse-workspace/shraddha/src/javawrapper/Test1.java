package javawrapper;

public class Test1 {
public static void main(String[] args) {
	int number=20;
	Integer num=number;
System.out.println(number);
System.out.println(num);
Integer num1=Integer.valueOf(number);
System.out.println(num1);
}
}
