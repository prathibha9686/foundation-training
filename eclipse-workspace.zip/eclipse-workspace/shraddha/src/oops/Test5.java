package oops;
class Book1{
	Book1(){
	
		System.out.println("default constructor gets executed");
	}
}

public class Test5 {
	public static void main(String[] args) {
		Book1 b1=new Book1();
		Book1 b2=new Book1();
		
	}

}
