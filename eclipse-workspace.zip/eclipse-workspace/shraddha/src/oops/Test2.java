package oops;
class Employee{
	String name;
	int batch;
	String company;
	
	Employee(){
		System.out.println("default constructor");
		
	}
	Employee( String name,int batch,String company){
		this.name=name;
		this.batch=batch;
		this.company=company;
	}
	void display() {
		System.out.println(name + " " + batch + " " + company);
	}
}
public class Test2 {
	public static void main(String[] args) {
		Employee obj1 = new Employee("Shraddha",88,"THBS");
		obj1.display();
		Employee obj2 = new Employee("Nayana",88,"THBS");
		obj2.display();
		Employee obj3 = new Employee("Vardhan",88,"THBS");
		obj3.display();
		Employee obj4 = new Employee("Gunasri",88,"THBS");
		obj4.display();
		
		
		
		
	
		
	}

}
