package oops;
class Car6{ 
	String brand="SUV";
	String model="range rover";
	String color="black";
	double price= 5000000.90;
	
 void car() {
	 
	 System.out.println(brand );
		System.out.println(model);
		System.out.println(color);
		
		System.out.println(price);
	
	
	}}

 
public class Test7 {
	public static void main(String[] args) {
		Car6 obj=new Car6();
		obj.car();
	}

}
