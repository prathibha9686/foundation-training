package oops;
class Book{
	int book_id =101;
	String book_name="java";
	void display()
{
		System.out.println(book_id +"\n" + book_name  );}
}

public class Test3 {
	public static void main(String[] args) {
		Book b1=new Book();
		b1.display();
		
	}

}
