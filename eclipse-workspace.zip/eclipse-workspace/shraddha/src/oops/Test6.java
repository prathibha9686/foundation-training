package oops;
class Bike{
	int speed;
	String name;
	String color;
	Bike(){
		System.out.println("default constructor");
	}
	Bike(int speed,String name,String color){
		this.speed=speed;
		this.name=name;
		this.color=color;
	}
	void display() {
		System.out.println(speed + " " + name + " " + color);
	}
	
}

public class Test6 {
	public static void main(String[] args) {
		Bike b1=new Bike(120,"yamaha","black");
		b1.display();
		
		Bike b2=new Bike(100,"ktm","black");
		b2.display();
		
	}

}
