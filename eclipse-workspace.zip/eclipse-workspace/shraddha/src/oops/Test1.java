package oops;
class Car{
	String brand="SUV";
	String model="range rover";
	String color="black";
	double price= 5000000.90;
}

public class Test1 {

	public static void main(String[] args) {
		Car obj=new Car();
		System.out.println(obj.brand);
		System.out.println(obj.model);
		System.out.println(obj.color);
		
		System.out.println( obj.price);
	}

}
