package oops;
class Counter{
	 int count=0;
	Counter(){
		count++;
		System.out.println(count);
	}
}

public class Teststatic {
public static void main(String[] args) {
	Counter obj1 =new Counter();
	Counter obj2 =new Counter();
	Counter obj3 =new Counter();
	
}
}
