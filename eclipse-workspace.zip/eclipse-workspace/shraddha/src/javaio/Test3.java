package javaio;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Test3 {
	public static void main(String[] args) {
	File f= new File("C:\\Users\\user62\\eclipse-workspace\\shraddha\\src\\javaio\\hello.txt");
	try {
		FileReader r =new FileReader(f);
		int i;
		while((i=r.read())!=-1) {
			System.out.println((char)i);
			}
		}catch (FileNotFoundException e){
			e.printStackTrace();
		}catch (IOException e){
	e.printStackTrace();
			
	}
	}

}
