package javaio;
import java.io.Writer;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;
public class json {
	public static void main(String[] args) {
		String msg="welcome to My application";
		try {
			FileWriter fw=new FileWriter("C:\\Users\\user62\\eclipse-workspace\\shraddha\\src\\javaio\\json.txt");
			JSONObject obj=new JSONObject();
			obj.put("id",1);
			obj.put("name","SHRADDHA");
			obj.put("age",21);
	
			JSONObject obj1=new JSONObject();
			obj1.put("id",2);
			obj1.put("name","Nayana");
			obj1.put("age",21);
			fw.write(obj.toJSONString()+"\n"+obj1.toJSONString());
			
			fw.close();
		}catch (IOException e) {
			e.printStackTrace();
		}System.out.println("done..");
	}

}
