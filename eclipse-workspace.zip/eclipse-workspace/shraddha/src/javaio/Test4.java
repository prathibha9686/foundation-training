package javaio;
import java.io.FileWriter;
import java.io.IOException;
public class Test4 {
	public static void main(String[] args) {
		String msg="welcome to My application";
		try {
			FileWriter fw=new FileWriter("C:\\Users\\user62\\eclipse-workspace\\shraddha\\src\\javaio\\hello.txt");
			fw.write(msg);
			fw.close();
		}catch (IOException e) {
			e.printStackTrace();
		}System.out.println("done..");
	}

}
