package javainheritance;
class Employee{
	int emp_id=1;
	String emp_name="John";
	
}
class Salary extends Employee{
	int salary=50000;
	
void display() {
	System.out.println(emp_id + " " + emp_name + " " + salary);
}
}
public class Test13 {
	public static void main(String[] args) {
		Salary obj =new Salary();
		obj.display();
		
	}

}

