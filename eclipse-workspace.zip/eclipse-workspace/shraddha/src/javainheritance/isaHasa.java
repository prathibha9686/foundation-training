package javainheritance;

public class isaHasa {

}
