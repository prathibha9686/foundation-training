package javainheritance;
class Q1{
	int num1=120;
}
class Q2 extends Q1{
	int num2=30;
	int res;
	void add() {
		res=num1+num2;
		System.out.println(res);
		}
}
class Q3 extends Q1{
 int num2= 40;
 int res;
 void cal() {
	 res=num1/num2;
	 System.out.println(res);
 }
}
class Q4 extends Q2{
	void display() {
		System.out.println("message from class Q4");
		add();
	
	}
}
public class Hybridinheritance {
public static void main(String[] args) {
	Q3 obj = new Q3();
	obj.cal();
	
}
}
