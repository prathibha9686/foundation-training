package javainheritance;
class A{
 int num=2;

}
class B extends A{
	void display() {
		System.out.println(num);
	}
}

public class Test11 {
	public static void main(String[] args) {
		B obj = new B();
		obj.display();
	}

}
