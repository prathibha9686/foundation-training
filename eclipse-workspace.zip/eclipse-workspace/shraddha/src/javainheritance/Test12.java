package javainheritance;
class A1{
	int num1=20;
	
}
class A2 extends A1{
	int num2=40;
	int result;
void addition() {
	result=num1+num2;
	System.out.println("sum is:" + result);
}
}
public class Test12 {
	public static void main(String[] args) {
		A2 obj =new A2();
		obj.addition();
		
	}

}
