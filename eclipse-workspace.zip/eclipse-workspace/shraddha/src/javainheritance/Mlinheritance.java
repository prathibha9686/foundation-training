package javainheritance;
class S1{
	int num1=100;
}
class S2 extends S1{
	int num2=200;
}
class S3 extends S2{
	int num3=300;
	int result;
	void addition() {
		result=num1+num2+num3;
		System.out.println("sum is:" + result);
	}
	
}
public class Mlinheritance {
	public static void main(String[] args) {
		S3 obj=new S3();
		obj.addition();
	}

}
