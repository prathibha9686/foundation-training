package javainterface;
interface Add {
	void addition(int x,int y);
}

public class Interface4 {
	public static void main(String[] args) {
		Add obj=new Add() {
			
		
		public void addition(int x,int y) {
			int res;
			res=x+y;
			System.out.println("sum of 2 numbers are : " + res);
		}
	};
	obj.addition(30,40);
	}

}
