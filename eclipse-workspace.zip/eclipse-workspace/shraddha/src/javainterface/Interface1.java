package javainterface;
interface I1{
 void display();
 void calculate();
}

public class Interface1 implements I1{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("message from display");
		
		
	}

	@Override
	public void calculate() {
		// TODO Auto-generated method stub
System.out.println("message from calculator");		
	}
	public static void main(String[] args) {
		Interface1 obj = new Interface1();
		obj.calculate();
		obj.display();
	}
	

}
