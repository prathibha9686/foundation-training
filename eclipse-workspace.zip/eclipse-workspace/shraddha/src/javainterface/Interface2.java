package javainterface;
interface I2{
	void add();	
}
interface I3{
	void mul();
}

public class Interface2 implements I2,I3 {

	@Override
	public void add() {
		// TODO Auto-generated method stub
		System.out.println("addition");
	}
	

	@Override
	public void mul() {
		// TODO Auto-generated method stub
		System.out.println("multiplication");
		
	}
public static void main(String[] args) {
	Interface2 obj = new Interface2();
	obj.add();
	obj.mul();
}	

}
