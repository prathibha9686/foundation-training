package javainterface;

interface I4{
	void add();	
}
interface I5 extends I4{
	void mul();
}

public class Interface3 implements I5 {

	@Override
	public void add() {
		// TODO Auto-generated method stub
		System.out.println("addition");
	}
	

	@Override
	public void mul() {
		// TODO Auto-generated method stub
		System.out.println("multiplication");
		
	}
public static void main(String[] args) {
	Interface2 obj = new Interface2();
	obj.add();
	obj.mul();
}	

}
