package accessspecifiers;

public class Test1 {
	private static int object=10;
	public static int value=200;
	public static void main(String[] args) {
		System.out.println(object);
		System.out.println(value);
	}

}
