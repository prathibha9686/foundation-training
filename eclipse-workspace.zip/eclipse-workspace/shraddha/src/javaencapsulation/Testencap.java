package javaencapsulation;

public class Testencap {
	public static void main(String[] args) {
	User u1=new User();
	u1.setUsername("john");
	u1.setPassword("john123");
	
	User u2=new User();
	u2.setUsername("jimmy");
	u2.setPassword("jimmy123");
	
	System.out.println(u1.getUsername() + " " + u1.getPassword());
	System.out.println(u2.getUsername() + " " + u2.getPassword());
	
	
	
	}

}
