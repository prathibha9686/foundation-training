package shraddha;

public class Variable {
	public static void main(String[] args) {
	 String name="Shraddha";
	 System.out.println("Name is :" + name);
	 
		
	}

}
