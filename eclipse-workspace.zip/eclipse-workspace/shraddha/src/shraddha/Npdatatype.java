package shraddha;

import java.util.Arrays;

public class Npdatatype {
	public static void main(String[] args) {
		int marks[] = { 30,32,47,65 };
		System.out.println("marks:"+ Arrays.toString(marks));
	}

}
