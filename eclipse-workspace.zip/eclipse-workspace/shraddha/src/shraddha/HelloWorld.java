package shraddha;

public class HelloWorld {
public static void main(String[] args) {
	int sum = 10+10;
	System.out.println (+sum);
	System.out.println("hello world");
}
}
