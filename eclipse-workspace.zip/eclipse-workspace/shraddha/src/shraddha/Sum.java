package shraddha;

public class Sum {
	public static void main(String[] args) {
	int num1 = 2;
	int num2 = 3;
	int res;
	res = num1 + num2;
	System.out.println("sum of two numbers is : " + res);
	}

}
