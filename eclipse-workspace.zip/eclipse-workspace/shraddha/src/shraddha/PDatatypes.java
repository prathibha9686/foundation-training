package shraddha;

public class PDatatypes {
	public static void main(String args[]) {
	int num = 100;
	float salary = 2.8765438000f;
	char ch = 'A';
	boolean flag = true;
	System.out.println(num);
	System.out.println(salary);
	System.out.println(ch);
	System.out.println(flag);
	}
	

}
