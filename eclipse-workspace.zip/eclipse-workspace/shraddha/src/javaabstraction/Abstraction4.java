package javaabstraction;
class Bike{
	int speed=100;
	Bike(){
		System.out.println("bikw is running at speed  " +  speed +  " km/hr");
		
	}
	void display() {
		System.out.println("msg from display");
		
	}
}
class Honda extends Bike{
	int speed = 200;
	Honda(){
		super();
		System.out.println("bike honda is good");
		
	}
	void show() {
		System.out.println(super.speed);
		System.out.println(this.speed);
		super.display();
	}
}

public class Abstraction4 {
public static void main(String[] args) {
	Honda obj = new Honda();
	obj.show();
}
}
