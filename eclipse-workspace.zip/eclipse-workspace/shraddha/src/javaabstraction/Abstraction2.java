package javaabstraction;
abstract class A1{
	void display() {
		System.out.println("message from display");
		
	}
	abstract void calculate();
	abstract void discount();
}

public class Abstraction2 extends A1 {
	void calculate() {
		System.out.println("message from calculate");
	}
	void discount() {
		System.out.println("message from discount");
		
	}
	public static void main(String[] args) {
		Abstraction2 obj=new Abstraction2();
		obj.discount();
		obj.calculate();
		obj.display();
	}

}
