package javaabstraction;
abstract class A{
	int num=3;
	void display() {
		System.out.println(num);
	}
	abstract void calculate();
}

public class Abstraction1 extends A{
void calculate() {
	System.out.println("message from calculate");
}
public static void main(String[] args) {
	Abstraction1 obj=new Abstraction1();
	obj.calculate();
	
}
}
