package com.example;

public class Passenger {
private String name;
private int age;
private char gender;
public Passenger() {
	System.out.println("default constructor");
}
public Passenger(String name, int age,char gender) {
	this.name=name;
	this.age=age;
	this.gender=gender;
}
public void display() {
	System.out.println("Passenger name: " + name + "\nPassenger age: " + age +"\nGender: "+ gender);
}
}
