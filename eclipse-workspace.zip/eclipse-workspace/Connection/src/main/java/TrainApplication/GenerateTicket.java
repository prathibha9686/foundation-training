package TrainApplication;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GenerateTicket {

	boolean generateTicket(String pnr, int  trainNumber, String input_date) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/train","root","admin");
			Statement stmt = con.createStatement();
			
			String sql = "INSERT INTO Ticket VALUES ('"+pnr+"',"+trainNumber+",'"+input_date+"')";
	         stmt.executeUpdate(sql);
			//stmt.executeUpdate("insert into Ticket values('"+pnr+"',"+trainNumber+",'"+input_date+"'");
			
//			System.out.println("Record Inserted Successfully.........");
			
//			ResultSet rs = stmt.executeQuery("Select * from Ticket");
//				
//				while(rs.next()) {
//					System.out.println(rs.getString(1)+ " " + rs.getInt(2) + " " + rs.getDate(3) + " "+rs.getInt(4));
//				}
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return true;
	}
}
