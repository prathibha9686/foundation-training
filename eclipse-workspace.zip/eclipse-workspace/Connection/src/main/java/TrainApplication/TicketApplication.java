package TrainApplication;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

class SortPassenger implements Comparator<Passenger> {

	public int compare(Passenger  o1, Passenger  o2) {
		return (o1.getName()).compareTo(o2.getName());
	}

}
public class TicketApplication {
	static void writeInFIle(String pnr, String source, String destination, int trainNumber, String train_name
			, String date, List<Passenger> passengerList, double [] priceDetails ) throws IOException{
		StringBuilder sb = new StringBuilder("");
		sb.append("PNR : " + pnr );
		sb.append(System.getProperty("line.separator"));
		sb.append("\nTrain no : " +  trainNumber );
		sb.append(System.getProperty("line.separator"));
		sb.append("\nTrain Name : " + train_name );
		sb.append(System.getProperty("line.separator"));
		sb.append("\nFrom : " + source );
		sb.append(System.getProperty("line.separator"));
		sb.append("\nTo : " + destination );
		sb.append(System.getProperty("line.separator"));
		sb.append("\nTravel Date : " + date );
		sb.append(System.getProperty("line.separator"));
		sb.append("\nPassengers: ");
		sb.append(System.getProperty("line.separator"));
		sb.append("\nName         Age         Gender         Fare");
		sb.append(System.getProperty("line.separator"));
		Collections.sort(passengerList, new SortPassenger());
		int n = passengerList.size();
		
		for(int i = 0; i< n; i++) {
			Passenger p = passengerList.get(i);
			if(p.getAge() <= 12) {
				sb.append(System.getProperty("line.separator"));
				sb.append("\n"+p.getName()+"       "+p.getAge()+"       "+p.getGender()+"        "
						+ ""+ priceDetails[0]);
			}else if( p.getAge() >= 60) {
				sb.append(System.getProperty("line.separator"));
				sb.append("\n"+p.getName()+"       "+p.getAge()+"       "+p.getGender()+"        "
						+ ""+ priceDetails[1]);
			}else if(p.getGender().equals("F") ) {
				sb.append(System.getProperty("line.separator"));
				sb.append("\n"+p.getName()+"       "+p.getAge()+"       "+p.getGender()+"        "
						+ ""+ priceDetails[3]);
			}else {
				sb.append(System.getProperty("line.separator"));
				sb.append("\n"+p.getName()+"       "+p.getAge()+"       "+p.getGender()+"        "
						+ ""+ priceDetails[2]);
			}
		}
		double d = (priceDetails[1] + priceDetails[2] + priceDetails[3] + priceDetails[0]);
		sb.append(System.getProperty("line.separator"));
		sb.append("Total Price : " +  d);
		
		File f = new File("C:\\Users\\user62\\eclipse-workspace\\Connection\\src\\main\\java\\TrainApplication\\"+pnr+".txt");
		FileWriter fw = new FileWriter("C:\\Users\\user62\\eclipse-workspace\\Connection\\src\\main\\java\\TrainApplication\\"+pnr+".txt");
		String s = sb.toString();
		fw.write(s);
		fw.close();
	}
	public static void main(String[] args) {

		Ticket t = new Ticket();

		String input_date = null;
		String train_name = null, pnr = null;
		String source = null, destination = null;
		List<Passenger> l = new ArrayList<Passenger>();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Train No : ");
		int trainNumber = sc.nextInt();
		int ticketPrice = 0;
		JDBCConnection jc = new JDBCConnection();
		Connection con = jc.getConnection();
		boolean flag = false;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from train");

			while(rs.next()) {
				if(trainNumber == rs.getInt(1)) {
					flag = true;
					break;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(flag) {
			System.out.println("Enter Travel Date : ");
			input_date = sc.next();

			String current_date = LocalDate.now().toString();
			if(input_date.compareTo(current_date) <= 0) {
				System.out.println("Date is invalid.");
			}else {
				Statement st;
				try {
					st = con.createStatement();
					ResultSet rs = st.executeQuery("select * from train where Train_Number = " + trainNumber);
					while(rs.next()) {
						train_name = rs.getString(2);
						source = rs.getString(3);
						destination = rs.getString(4);
						ticketPrice = rs.getInt(5); // take price from database
						pnr = t.getPNR(source, destination, input_date);

					}
					//					System.out.println(rs.getInt(1)+ " "+rs.getString(3)+" " + rs.getString(4));

					//System.out.println(pnr);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Enter Number of Passengers : ");
				int number_of_passenger = sc.nextInt();
				for(int i = 0; i< number_of_passenger; i++) {
					sc = new Scanner(System.in);
					System.out.println("Enter Passenger Name : ");
					String name = sc.next();
					System.out.println("Enter Age : ");
					int age = sc.nextInt();
					System.out.println("Enter Gender(M/F) : ");
					String gender = sc.next();

					Passenger p = new Passenger(name, age, gender);
					l.add(p);

				}
			}
		}else {
			System.out.println("The Train Number is Invalid.");
		}
		GenerateTicket gt = new GenerateTicket();
		boolean ticketCreated = gt.generateTicket(pnr, trainNumber, input_date);  // return flag = true -> if successfully ticket generated
		System.out.println("Ticket Booked with PNR : " + pnr);
		
		if(ticketCreated) {
			double [] priceDetails = t.calcTotalTicketPrice(l, ticketPrice); 
			try {
				writeInFIle(pnr, source, destination, trainNumber, train_name
						 , input_date, l, priceDetails);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			System.out.println("There is a mistake");
			}
			
		}
	}
