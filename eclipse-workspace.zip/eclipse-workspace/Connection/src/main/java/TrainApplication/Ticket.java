package TrainApplication;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class Ticket {
	private static int counter = 99; //create it in database, 
	public static String getPNR(String source, String destination, String date) {
		String[] s = date.split("-");
		return source.charAt(0) + "" + destination.charAt(0) + "" + s[0]+""+s[1]+""+s[2]+ "" + counter;
	}
	public static double [] calPassengerFair(double child, double adult, double female, double adult1, int ticketPrice) {

		child = child*(ticketPrice - ticketPrice/2);
		adult = adult*(ticketPrice - ticketPrice*((double)60/100));
		female = female*(ticketPrice - ticketPrice/4);
		adult1 = adult1*(ticketPrice);
		double sum = child+ adult+ female+ adult1;
		double [] d = {child, adult, adult1, female, sum};
		return d;
	}
	public static double [] calcTotalTicketPrice(List<Passenger> passengerList, int tp) {
		double child = 0; // for age <= 12
		double adult = 0; //for age >= 60
		double female = 0;
		double adult1 = 0;// for age >12 &&  age <60
		for(Passenger p: passengerList) {
			if(p.getAge() <= 12) {
				child++;
			}else if( p.getAge() >= 60) {
				adult++;
			}else if(p.getGender().equals("F") ) {
				female++;
			}else {
				adult1++;
			}
		}
		return calPassengerFair(child, adult, adult1, female, tp);
	}
}