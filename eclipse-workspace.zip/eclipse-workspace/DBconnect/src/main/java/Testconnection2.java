import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class Testconnection2 {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sampleDB1","root","admin");
			
			Statement stmt=con.createStatement();
			stmt.executeUpdate("insert into contacts values(104,'jackson','mangalore','India')");
			System.out.println("record inserted successfully");
			System.out.println("----------------------------------------");
			ResultSet rs= stmt.executeQuery("select * from contacts");
			while(rs.next()) {
				System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4));
			}
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
