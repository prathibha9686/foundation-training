package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.DAO.UserDAO;
import com.example.bean.User;

@Controller
public class UserController {
	@Autowired
	UserDAO userdao;
	
	@RequestMapping("/userform")
	public String showForm(Model model) {
		model.addAttribute("command",new User());
		return "userform";
	}
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String save(@ModelAttribute("user") User user) {
		userdao.insertUser(user);
		return "redirect:/viewuser";
	}
	@RequestMapping("/viewuser")
	public String viewUser(Model model) {
		List<User> user=userdao.getUsers();
		model.addAttribute("list", user);
		return "viewuser";
	}
	@RequestMapping("/edituser/{id}") 
	public String edit(@PathVariable int id,Model model) {
		User user=userdao.getUserbyId(id);
		model.addAttribute("command", user);
		return "usereditform";
	}
	@RequestMapping(value="/editsave",method=RequestMethod.POST)
	public String editsave(@ModelAttribute("user")User user) {
		userdao.updateUser(user);
		return "redirect:/viewuser";
	}
	@RequestMapping(value="/deleteuser",method=RequestMethod.GET)
	public String delete(@PathVariable int id) {
		userdao.deleteUser(id);
		return "redirect:/viewuser";
	}
}
