package Tests;
import static org.junit.Assert.assertEquals;

import examples.*;
import org.junit.Test;



public class Test1 {
	
	@Test
public void testAdd() {

	assertEquals(70,Example1.addition(40,30));
	assertEquals(40,Example1.addition(20,30));
	
	
	
}
}
