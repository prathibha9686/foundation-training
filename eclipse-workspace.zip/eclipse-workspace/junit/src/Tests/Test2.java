
package Tests;
import static org.junit.Assert.assertEquals;

import examples.*;
import org.junit.Test;


public class Test2 {
	@Test
public void testAdd() {

	assertEquals(10,Example2.subtraction(40,30));
	assertEquals(20,Example2.subtraction(50,30));
	
	
	
}
}
