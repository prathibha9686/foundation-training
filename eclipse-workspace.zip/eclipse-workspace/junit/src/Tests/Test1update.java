package Tests;
import static org.junit.Assert.assertEquals;

import examples.*;
import org.junit.Test;
import org.junit.After;
import org.junit.Before;


public class Test1update {
	@Before
	public void beforeTest() {
		System.out.println("before test");
	}
	@Test
public void testAdd() {

	System.out.println("actual test");
	assertEquals(60,Example1.addition(30, 30));
	}
@After
public void afterTest(){
	System.out.println("after test");
}

}
