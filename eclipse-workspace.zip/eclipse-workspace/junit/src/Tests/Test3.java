package Tests;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import examples.*;
public class Test3 {
	@Test
public void testValidate() {
		//assertEquals("Valid",Example3.validate("admin","admin123"));
	//assertEquals("Blank username",Example3.validate("","admin123"));
		//assertEquals("Blank password",Example3.validate("admin",""));
		//assertEquals("Blank username and password",Example3.validate("",""));
		assertEquals("Invalid",Example3.validate("admin123","admin"));
		
	}
}

	
