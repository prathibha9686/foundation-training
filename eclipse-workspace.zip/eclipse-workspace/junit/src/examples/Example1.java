package examples;

class Calculation{
	public static int addition(int x,int y) {
		return x+y;
	}
}
public class Example1 extends Calculation{
	public static void main(String[] args) {
		Calculation obj=new Calculation();
		System.out.println("sum :" +obj.addition(20,20));
	}

}
