package examples;

class Calculation1{
	public static int subtraction(int x,int y) {
		return x-y;
	}
}
public class Example2 extends Calculation1{
	public static void main(String[] args) {
		Calculation1 obj=new Calculation1();
		System.out.println("sum :" +obj.subtraction(20,20));
	}

}



