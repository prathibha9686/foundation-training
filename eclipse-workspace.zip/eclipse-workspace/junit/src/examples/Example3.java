package examples;
import java.util.Scanner;
class validate{
	
	public static String validate(String username,String password) {
		if(username.equals("admin")&& password.equals("admin123"))
		return "Valid";
		else if(username.equals("")&& password.equals("admin123"))
		return "Blank username";
		else if(username.equals("admin")&& password.equals(""))
		return "Blank password";
		else if(username.equals("")&& password.equals(""))
		return "Blank username and password";
		else
			return"Invalid";
		
	}
	

}
public class Example3 extends validate{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter username");
	String username=sc.next();
	System.out.println("enter password");
	String password=sc.next();
	System.out.println(validate(username,password));
	}
	
}