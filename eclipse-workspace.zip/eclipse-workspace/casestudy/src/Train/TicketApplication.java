package Train;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TicketApplication {

public static void main(String[] args) {

Ticket t = new Ticket();

String input_date = null;
String pnr = null;

List<Passenger> l = new ArrayList<Passenger>();

Scanner sc = new Scanner(System.in);
System.out.println("Enter Train No : ");
int trainNumber = sc.nextInt();

JDBCConnection jc = new JDBCConnection();
Connection con = jc.getConnection();
boolean flag = false;
try {
Statement st = con.createStatement();
ResultSet rs = st.executeQuery("select * from train");

while(rs.next()) {
if(trainNumber == rs.getInt(1)) {
flag = true;
break;
}
}
} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
if(flag) {
System.out.println("Enter Travel Date : ");
input_date = sc.next();

String current_date = LocalDate.now().toString();
if(input_date.compareTo(current_date) <= 0) {
System.out.println("Date is invalid.");
}else {
Statement st;
try {
st = con.createStatement();
ResultSet rs = st.executeQuery("select * from train where Train_Number = " + trainNumber);
while(rs.next()) {
System.out.println(rs.getInt(1)+ " "+rs.getString(3)+" " + rs.getString(4));
pnr = t.getPNR(rs.getString(3), rs.getString(4), input_date);

}
// System.out.println(rs.getInt(1)+ " "+rs.getString(3)+" " + rs.getString(4));

System.out.println(pnr);

} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
System.out.println("Enter Number of Passengers : ");
int number_of_passenger = sc.nextInt();
for(int i = 0; i< number_of_passenger; i++) {
sc = new Scanner(System.in);
System.out.println("Enter Passenger Name : ");
String name = sc.next();
System.out.println("Enter Age : ");
int age = sc.nextInt();
System.out.println("Enter Gender(M/F) : ");
char gender = sc.next().charAt(0);

Passenger p = new Passenger(name, age, gender);
l.add(p);

}
}
}else {
System.out.println("The Train Number is Invalid.");
}
GenerateTicket gt = new GenerateTicket();
gt.generateTicket(pnr, trainNumber, input_date);
System.out.println("Ticket Booked with PNR : " + pnr);


}
}