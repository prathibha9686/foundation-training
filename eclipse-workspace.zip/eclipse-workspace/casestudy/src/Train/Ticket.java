package Train;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class SortPassenger implements Comparator<Passenger> {

public int compare(Passenger o1, Passenger o2) {
return (o1.getName()).compareTo(o2.getName());
}

}
public class Ticket {
private final static int ticketPrice = 900;
private static int counter = 99;
public static String getPNR(String source, String destination, String date) {
counter++;
String[] s = date.split("-");
return source.charAt(0) + "" + destination.charAt(0) + "_" + s[0]+""+s[1]+""+s[2]+ "_" + counter;
}
public static int calPassengerFair(int child, int adult, int female) {

child = ticketPrice - ticketPrice*(50/100);
adult = ticketPrice - ticketPrice*(60/100);
female = ticketPrice - ticketPrice*(25/100);
return child+adult+female;
}
public static int calcTotalTicketPrice(List<Passenger> passengerList ) {
int child = 0; // for age <= 12
int adult = 0; //for age >= 60
int female = 0;
Collections.sort(passengerList,new SortPassenger());
for(Passenger p: passengerList) {
if(p.getAge() <= 12) {
child++;
}else if( p.getAge() >= 60) {
adult++;
}else if(p.getGender()=='F' ) {
female++;
}
}
return calPassengerFair(child, adult, female);
}
}