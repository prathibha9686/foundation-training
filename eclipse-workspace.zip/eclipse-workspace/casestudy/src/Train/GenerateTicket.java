package Train;

public class GenerateTicket {

	public void generateTicket(String pnr, int trainNumber, String input_date) {
		// TODO Auto-generated method stub
		
	}

}
