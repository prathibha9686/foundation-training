package com.example;
import org.springframework.beans.factory.xml.XmlBeanFactory;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


public class TestTrain {
	public static void main(String[] args) {
	Resource rs=new ClassPathResource("applicationContext4.xml");
	BeanFactory factory=new XmlBeanFactory(rs);
Train user=(Train) factory.getBean("Bean3");
		user.display();
}
	

}
