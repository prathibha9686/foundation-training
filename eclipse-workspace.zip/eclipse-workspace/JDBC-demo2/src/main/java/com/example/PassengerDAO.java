package com.example;
import org.springframework.jdbc.core.JdbcTemplate;

public class PassengerDAO {
	private JdbcTemplate jdbctemplate;
	
	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}
	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}
	void setJdbcTemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate=jdbctemplate;
	}
	public int savePassenger(Passenger user) {
		String query="insert into passengers values('"+user.getP_name()+"',"+user.getP_age()+",'"+user.getP_gender()+"')";
		return jdbctemplate.update(query);
	}
	public int updatePassenger(Passenger user) {
	
		String query="update passengers set p_age = "+user.getP_age()+",p_gender='"+user.getP_gender()+"' where p_name = "+user.getP_name();
		return jdbctemplate.update(query);
	}
}

