package com.example;

public class Passenger {
private String p_name;
private int p_age;
private char p_gender;

Passenger(){
	System.out.println("Default Constructor");
}
Passenger (String p_name,int p_age,char p_gender){
	this.p_name=p_name;
	this.p_age=p_age;
	this.p_gender=p_gender;
}
public String getP_name() {
	return p_name;
}
public void setP_name(String p_name) {
	this.p_name = p_name;
}
public int getP_age() {
	return p_age;
}
public void setP_age(int p_age) {
	this.p_age = p_age;
}
public char getP_gender() {
	return p_gender;
}
public void setP_gender(char p_gender) {
	this.p_gender = p_gender;
}


}
