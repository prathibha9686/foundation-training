package com.example;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestPassenger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context =  new ClassPathXmlApplicationContext("applicationContext.xml"); 
		//Resource rs=new ClassPathResource("applicationContext.xml");
		//BeanFactory factory=new XmlBeanFactory(rs);
		
		PassengerDAO userdao=(PassengerDAO) context.getBean("userDAO");
		int result=userdao.savePassenger(new Passenger("Shraddha",21,'F'));
		System.out.println(result);
		int result1=userdao.updatePassenger(new Passenger("Shraddha",22,'F'));
		System.out.println(result1);
	}

}


